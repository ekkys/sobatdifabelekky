<div id="login" class="section md-padding">

	<div class="container">

			<!-- Section header -->
			<div class="section-header text-center">
				<h2 class="title">Layanan Pendampingan</h2>
			</div>
			<!-- /Section header -->

			<div class="row">
				<!-- Layanan -->
				<div class=" col-md-6" >
					<div class="service">
						<h3>Sobat Penerjemah Isyarat</h3>
						<p>Sobat penerjemah akan membantu anda menerjemahkan bahasa isyarat ke bahasa lisan dan sebaliknya</p><br>
						<a href="" class="btn-lg btn-success">Ajukan</a>
					</div>
				</div>

				<div class=" col-md-6">
					<div class="service">
						<h3>Sobat Notula</h3>
						<p>Sobat Notula akan membantu anda mencatat dari brraile ke teks biasa dan sebaliknya</p><br>
						<a href="" class="btn-lg btn-success">Ajukan</a><br>
					</div>

				</div>

			</div>


			<div class="row">
				<div class=" col-md-6" >
					<div class="service">
						<h3>Sobat Akses</h3>
						<p>Sobat akses akan membantu sobat tuna netra dalam perjalaanan menuju lokasi tujuan anda</p>
						<a href="" class="btn-lg btn-success">Ajukan</a>
					</div>
				</div>
				<div class=" col-md-6" >
					<div class="service">
						<h3>Sobat Virtual</h3>
						<p>Sobat virtual akan membantu anda secara virtual</p><br>
						<a href="" class="btn-lg btn-success">Ajukan</a><br>
					</div>

				</div>
				<!-- /Layanan -->
			</div>

			
	
	</div>
</div>

