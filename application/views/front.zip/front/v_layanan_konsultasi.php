<div id="login" class="section md-padding">

	<div class="container">

		<div class="row">

			<!-- Section header -->
			<div class="section-header text-center">
				<h2 class="title">Layanan Konsultasi</h2>
			</div>
			<!-- /Section header -->

			<div class="row">
				<!-- Layanan -->
				<div class=" col-md-6" >
					<div class="service">
						<h3>Tinggalkan Pesan</h3>
						<p>Anda bisa melakukan konsultasi tentang difabel dengan mengisi formulir berikut dan mencantumkan no.wa dan email aktif sehingga kami bisa memberikan balasan sesegera mungkin</p><br>
						<a href="" class="btn-lg btn-success">Curhat Disini</a>
					</div>
				</div>

				<div class=" col-md-6">
					<div class="service">
						<h3>Atur Jadwal</h3>
						<p>Anda bisa melakukan konsultasi dengan kami secara tatap muka atau daring dengan mengatur jadwal terlebih dahulu.</p><br><br><br>
						<a href="" class="btn-lg btn-success">Atur jadwal</a><br>
					</div>

				</div>

			</div>
			
		</div>
	</div>
</div>

