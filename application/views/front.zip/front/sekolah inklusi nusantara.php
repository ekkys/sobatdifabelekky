		<!-- Sekolah Inklusi Nusantara -->
		<div id="features" class="section md-padding bg-grey">

			<!-- Container -->
			<div class="container">

				<!-- Row -->
				<div class="row">

					<!-- why choose us content -->
					<div class="col-md-6">
						<div class="section-header">
							<h2 class="title">Sekolah Inklusi Nusantara</h2>
						</div>
						<p>Merupakan kelas online  yang terdiri dari : </p>
						<div class="feature">
							<i class="fa fa-check"></i>
							<p>Sistem Isyarat Bahasa Indonesia</p>
						</div>
						<div class="feature">
							<i class="fa fa-check"></i>
							<p>Kelas Bahasa Isyarat Indonesia <b>BISINDO</b></p>
						</div>
						<div class="feature">
							<i class="fa fa-check"></i>
							<p>Tutorial Komputer</p>
						</div>
						<div class="feature">
							<i class="fa fa-check"></i>
							<p>Tutorial Bahasa Isyarat Inggris</p>
						</div>

					</div>
					<!-- /why choose us content -->

					<!-- About slider -->
					<div class="col-md-6">
						<div id="about-slider" class="owl-carousel owl-theme">
							<img class="img-responsive" src="<?php echo base_url();?>assets2/img/about1.jpg" alt="">
							<img class="img-responsive" src="<?php echo base_url();?>assets2/img/about2.jpg" alt="">
							<img class="img-responsive" src="<?php echo base_url();?>assets2/img/about1.jpg" alt="">
							<img class="img-responsive" src="<?php echo base_url();?>assets2/img/about2.jpg" alt="">
						</div>
					</div>
					<!-- /About slider -->

				</div>
				<!-- /Row -->

			</div>
			<!-- /Container -->

		</div>
		<!-- /Sekolah Inklusi Nusantara -->